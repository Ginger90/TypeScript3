class Abbigliamento {
    prezzoivaesclusa: number;
    prezzoivainclusa: number;
    saldo: number;
    constructor(_prezzoivaesclusa: number, _prezzoivainclusa: number, _saldo: number) {
        this.prezzoivaesclusa = _prezzoivaesclusa;
        this.prezzoivainclusa = _prezzoivainclusa;
        this.saldo = _saldo;
    }
    getSaldoCapo(): number {
        return this.prezzoivainclusa * this.saldo / 100;
    }
    getAcquistoCapo(): number {
        return this.prezzoivainclusa - this.getSaldoCapo();
    }
}




fetch("http://localhost:3000/Abbigliamento").then(res => res.json()).then((data: fetchData[]) => {
    console.log(data);

    data.forEach((e) => {
       let x = new Abbigliamento (e.prezzoivaesclusa, e.prezzoivainclusa, e.saldo);
       console.log(x);
       console.log(x.getAcquistoCapo());

    })
   
})

interface fetchData {
    prezzoivaesclusa: number,
    prezzoivainclusa: number,
    saldo: number
}