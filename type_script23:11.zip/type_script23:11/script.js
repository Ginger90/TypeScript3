"use strict";
class Abbigliamento {
    constructor(_prezzoivaesclusa, _prezzoivainclusa, _saldo) {
        this.prezzoivaesclusa = _prezzoivaesclusa;
        this.prezzoivainclusa = _prezzoivainclusa;
        this.saldo = _saldo;
    }
    getSaldoCapo() {
        return this.prezzoivainclusa * this.saldo / 100;
    }
    getAcquistoCapo() {
        return this.prezzoivainclusa - this.getSaldoCapo();
    }
}
fetch("http://localhost:3000/Abbigliamento").then(res => res.json()).then((data) => {
    console.log(data);
    data.forEach((e) => {
        let x = new Abbigliamento(e.prezzoivaesclusa, e.prezzoivainclusa, e.saldo);
        console.log(x);
        console.log(x.getAcquistoCapo());
    });
});
